var customScript = document.createElement('script');
customScript.setAttribute('src','//iknow.code-lab.co.uk/scripts/app.min.js');
document.querySelector('body').appendChild(customScript);